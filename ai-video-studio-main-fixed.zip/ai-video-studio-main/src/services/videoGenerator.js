export async function generateVideo(payload = {}) {
  const { prompt, mode, model, duration, quality, aspectRatio, referenceImage } = payload;

  if (!prompt?.trim() && mode !== 'image') {
    return {
      status: 'error',
      error: 'يرجى كتابة وصف الفيديو.',
      result: null,
    };
  }

  if (!model) {
    return {
      status: 'error',
      error: 'يرجى اختيار موديل.',
      result: null,
    };
  }

  if (!duration || !quality || !aspectRatio) {
    return {
      status: 'error',
      error: 'يرجى إكمال إعدادات الفيديو.',
      result: null,
    };
  }

  try {
    const response = await fetch('/api/video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mode,
        model,
        duration,
        quality,
        aspectRatio,
        prompt,
        referenceImage,
      }),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok || !data.ok) {
      return {
        status: 'error',
        error: data?.message || 'تعذر إنشاء الفيديو حاليًا، حاول مرة أخرى.',
        result: null,
      };
    }

    return {
      status: 'success',
      error: null,
      result: {
        videoUrl: data.videoUrl,
        model: data.model,
        duration: data.duration,
        quality: data.quality,
        aspectRatio: data.aspectRatio,
      },
    };
  } catch (error) {
    return {
      status: 'error',
      error: 'تعذر الاتصال بخادم توليد الفيديو. تحقق من اتصالك بالإنترنت.',
      result: null,
    };
  }
}
