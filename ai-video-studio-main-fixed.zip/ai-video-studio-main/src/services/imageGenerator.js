async function pollImageJob(jobId, { maxAttempts = 20, intervalMs = 3000 } = {}) {
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, intervalMs));

    const response = await fetch(`/api/image?jobId=${encodeURIComponent(jobId)}`, {
      method: 'GET',
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok || !data.ok) {
      return {
        status: 'error',
        error: data?.message || 'تعذر إنشاء الصورة حاليًا، حاول مرة أخرى.',
        result: null,
      };
    }

    if (data.resultStatus === 'completed' && data.imageUrl) {
      return {
        status: 'success',
        error: null,
        result: { imageUrl: data.imageUrl },
      };
    }
  }

  return {
    status: 'error',
    error: 'استغرقت عملية إنشاء الصورة وقتًا أطول من المتوقع.',
    result: null,
  };
}

export async function generateImage(payload = {}) {
  const { description, mode, model, aspectRatio, quality, referenceImage } = payload;

  if (!description?.trim() && mode !== 'image') {
    return {
      status: 'error',
      error: 'يرجى كتابة وصف الصورة.',
      result: null,
    };
  }

  if (!model) {
    return {
      status: 'error',
      error: 'يرجى اختيار موديل.',
      result: null,
    };
  }

  if (!aspectRatio || !quality) {
    return {
      status: 'error',
      error: 'يرجى إكمال إعدادات الصورة.',
      result: null,
    };
  }

  try {
    const response = await fetch('/api/image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        mode,
        model,
        prompt: description,
        aspectRatio,
        quality,
        referenceImage,
      }),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok || !data.ok) {
      return {
        status: 'error',
        error: data?.message || 'تعذر إنشاء الصورة حاليًا، حاول مرة أخرى.',
        result: null,
      };
    }

    if (data.imageUrl) {
      return {
        status: 'success',
        error: null,
        result: { imageUrl: data.imageUrl },
      };
    }

    if (data.jobId) {
      return pollImageJob(data.jobId);
    }

    return {
      status: 'error',
      error: 'تعذر إنشاء الصورة حاليًا، حاول مرة أخرى.',
      result: null,
    };
  } catch (error) {
    return {
      status: 'error',
      error: 'تعذر الاتصال بخادم توليد الصور. تحقق من اتصالك بالإنترنت.',
      result: null,
    };
  }
}
