const APIFRAME_BASE_URL = 'https://api.apiframe.ai';

// Apiframe model slugs for our two image models.
const imageModelMap = {
  'Seedream v5.0 Lite': 'seedream-5-lite',
  'FLUX.2 Pro': 'flux-2-pro',
};

// Aspect ratios the UI offers, and how each provider expects them.
// Seedream accepts any "W:H" string. Flux 2 Pro only supports these 5 ratios,
// so 4:5 (not supported by Flux) falls back to the closest one, 3:4.
const aspectRatioMap = {
  '1:1': { seedream: '1:1', flux: '1:1' },
  '9:16': { seedream: '9:16', flux: '9:16' },
  '16:9': { seedream: '16:9', flux: '16:9' },
  '4:5': { seedream: '4:5', flux: '3:4' },
  '3:4': { seedream: '3:4', flux: '3:4' },
};

// UI quality tiers mapped to each provider's own resolution options.
const qualityMap = {
  '480p': { seedream: '2K', flux: '0.5MP' },
  '720p': { seedream: '2K', flux: '1MP' },
  '1080p': { seedream: '3K', flux: '2MP' },
  '4K': { seedream: '3K', flux: '4MP' },
};

function ensureSupportedModel(modelName) {
  if (!modelName || !imageModelMap[modelName]) {
    throw new Error('يرجى اختيار موديل صالح.');
  }

  return modelName;
}

export function validateImageRequest(payload) {
  const mode = payload.mode || 'image';
  const prompt = (payload.prompt || '').trim();
  const modelName = ensureSupportedModel(payload.model);
  const aspectRatio = payload.aspectRatio;
  const quality = payload.quality;

  if (mode === 'image' && !payload.referenceImage && !prompt) {
    throw new Error('يرجى كتابة وصف الصورة.');
  }

  if (mode === 'text' && !prompt) {
    throw new Error('يرجى كتابة وصف الصورة.');
  }

  if (!aspectRatio || !aspectRatioMap[aspectRatio]) {
    throw new Error('هذا المقاس غير متاح لهذا الموديل.');
  }

  if (!quality || !qualityMap[quality]) {
    throw new Error('هذه الجودة غير مدعومة لهذا الموديل.');
  }

  return {
    model: modelName,
    mode,
    prompt: prompt || '',
    aspectRatio,
    quality,
    referenceImage: payload.referenceImage || null,
  };
}

function buildRequestBody(normalized) {
  const modelSlug = imageModelMap[normalized.model];
  const ratios = aspectRatioMap[normalized.aspectRatio];
  const qualities = qualityMap[normalized.quality];

  if (modelSlug === 'seedream-5-lite') {
    return {
      prompt: normalized.prompt,
      model: modelSlug,
      seedreamParams: {
        aspect_ratio: ratios.seedream,
        size: qualities.seedream,
        ...(normalized.referenceImage ? { image_input: [normalized.referenceImage] } : {}),
      },
    };
  }

  // flux-2-pro
  return {
    prompt: normalized.prompt,
    model: modelSlug,
    fluxParams: {
      resolution: qualities.flux,
      aspect_ratio: ratios.flux,
      ...(normalized.referenceImage
        ? { image_prompt: normalized.referenceImage, image_prompt_strength: 0.5 }
        : {}),
    },
  };
}

function extractErrorMessage(status, data) {
  if (status === 401 || status === 403) return 'مفتاح Apiframe غير صحيح أو منتهي الصلاحية.';
  if (status === 402) return 'رصيد Apiframe غير كافٍ. اشحن رصيد إضافي من لوحة التحكم.';
  if (status === 429) return 'تم تجاوز حد الطلبات على Apiframe. حاول لاحقًا.';
  if (status >= 500) return 'خطأ في خدمة Apiframe. حاول مرة أخرى.';

  const message = data?.error?.message || data?.message || data?.error || 'تعذر إنشاء الصورة حاليًا.';
  return typeof message === 'string' ? message : 'تعذر إنشاء الصورة حاليًا.';
}

// The frontend sends the reference image as a base64 data URI (data:image/...;base64,...).
// Apiframe's generation endpoint needs a publicly reachable URL, not a data URI, so we
// upload it first and swap in the hosted URL it returns.
async function uploadReferenceImage(dataUri, apiKey) {
  const match = /^data:([^;]+);base64,(.+)$/.exec(dataUri || '');

  if (!match) {
    throw new Error('صيغة الصورة المرجعية غير صالحة.');
  }

  const [, mimeType, base64Data] = match;
  const buffer = Buffer.from(base64Data, 'base64');
  const formData = new FormData();
  formData.append('image', new Blob([buffer], { type: mimeType }), 'reference-image');

  const response = await fetch(`${APIFRAME_BASE_URL}/upload`, {
    method: 'POST',
    headers: { 'X-API-Key': apiKey },
    body: formData,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok || !(data.imageURL || data.imageUrl)) {
    throw new Error(extractErrorMessage(response.status, data) || 'تعذر رفع الصورة المرجعية.');
  }

  return data.imageURL || data.imageUrl;
}

export async function createImageGeneration(payload) {
  try {
    const normalized = validateImageRequest(payload);
    const apiKey = process.env.IMAGE_PROVIDER_API_KEY;

    if (!apiKey) {
      return {
        ok: false,
        status: 503,
        message: 'لم يتم تهيئة مفتاح Apiframe في الخادم. أضف IMAGE_PROVIDER_API_KEY في متغيرات البيئة.',
      };
    }

    const requestBody = buildRequestBody(
      normalized.referenceImage
        ? { ...normalized, referenceImage: await uploadReferenceImage(normalized.referenceImage, apiKey) }
        : normalized
    );

    const response = await fetch(`${APIFRAME_BASE_URL}/v2/images/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': apiKey,
      },
      body: JSON.stringify(requestBody),
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return {
        ok: false,
        status: response.status || 500,
        message: extractErrorMessage(response.status, data),
        details: data?.error || 'Apiframe request failed',
      };
    }

    if (!data.jobId) {
      return {
        ok: false,
        status: 502,
        message: 'لم يرد Apiframe بمعرّف المهمة المطلوبة.',
        details: 'Missing jobId in Apiframe response',
      };
    }

    return {
      ok: true,
      status: 202,
      jobId: data.jobId,
      message: 'جاري إنشاء الصورة...',
    };
  } catch (error) {
    return {
      ok: false,
      status: 500,
      message: error?.message || 'حدث خطأ أثناء الاتصال بالخدمة.',
    };
  }
}

export async function getImageJobStatus(jobId) {
  const apiKey = process.env.IMAGE_PROVIDER_API_KEY;

  if (!apiKey || !jobId) {
    return {
      ok: false,
      status: 503,
      message: 'لم يتم تهيئة مفتاح Apiframe في الخادم. أضف IMAGE_PROVIDER_API_KEY في متغيرات البيئة.',
    };
  }

  const response = await fetch(`${APIFRAME_BASE_URL}/v2/jobs/${encodeURIComponent(jobId)}`, {
    method: 'GET',
    headers: {
      'X-API-Key': apiKey,
    },
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    return {
      ok: false,
      status: response.status || 500,
      message: extractErrorMessage(response.status, data),
    };
  }

  if (data.status === 'COMPLETED') {
    const imageUrl = data.result?.images?.[0] || null;

    if (!imageUrl) {
      return {
        ok: false,
        status: 502,
        message: 'تعذر الحصول على رابط الصورة بعد اكتمالها.',
      };
    }

    return {
      ok: true,
      status: 200,
      imageUrl,
      jobId,
      resultStatus: 'completed',
    };
  }

  if (data.status === 'FAILED') {
    return {
      ok: false,
      status: 400,
      message: data.error?.message || 'تعذر إنشاء الصورة حاليًا، حاول مرة أخرى.',
    };
  }

  // QUEUED or PROCESSING
  return {
    ok: true,
    status: 202,
    jobId,
    resultStatus: 'pending',
  };
}
